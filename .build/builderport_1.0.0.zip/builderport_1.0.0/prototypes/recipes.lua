data:extend({
  {
    type = "recipe",
    name = "builderport",
    enabled = false,
    ingredients = {
      { "roboport", 10 },
      { "electronic-circuit", 50 },
      { "processing-unit", 10 }
    },
    result = "builderport",
    energy_required = 60
  }
})
